<?php
// Establish database connection
$servername = "127.0.0.1";
$username = "sqluser";
$password = "andrearojo";
$dbname = "SBM";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables to store form data
$name = $email = $feedback = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate form data
    $name = sanitize_input($_POST["name"]);
    $email = sanitize_input($_POST["email"]);
    $feedback = sanitize_input($_POST["feedback"]);

    // Prepare and execute SQL statement to insert feedback into the database
    $stmt = $conn->prepare("INSERT INTO Feedback (PassengerID, MinibusID, Date, Rating, Comments) VALUES (?, ?, ?, ?, ?)");
    $passengerID = 1; // Replace with actual PassengerID
    $minibusID = 1; // Replace with actual MinibusID
    $date = date("Y-m-d");
    $rating = 5; // Replace with actual rating value
    $stmt->bind_param("iisis", $passengerID, $minibusID, $date, $rating, $feedback);

    if ($stmt->execute()) {
        // Feedback inserted successfully
        echo "<script>alert('Thank you for your feedback!');</script>";
    } else {
        // Error occurred during insertion
        echo "Error: " . $stmt->error;
    }

    // Close statement
    $stmt->close();
}

// Function to sanitize input data
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Close database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback</title>
    <link rel="stylesheet" href="styles.css"> <!-- Include the CSS file -->
    <style>

        body {
            background: rgb(96,116,210);
            background: linear-gradient(90deg, rgba(96,116,210,1) 0%, rgba(135,192,255,1) 44%, rgba(83,255,215,1) 100%);
            margin: 0px;
        }

        .navbar {
            overflow: hidden;
            background-color: #4B5B65;
        }

        .navbar a {
         float: left;
         color: #f2f2f2;
         text-align: center;
         padding: 20px 20px;
         text-decoration: none;
         font-size: 20px;
        }

        h1 {
            font-size: 30px;
            color: #1C3D54;
            font-family: Verdana;
            text-align: center;
            margin-top: 100px;
            font-size: 70px;
            margin-bottom: 0px;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        .feedback-container {
            margin-top: 20px;
            font-family: Verdana;
            font-size: 20px;
        }

        .feedback-form {
            max-width: 400px;
            margin: auto;
        }

        .feedback-form input[type=text],
        .feedback-form textarea {
            width: 100%;
            padding: 10px;
            margin: 6px 0;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .feedback-form input[type=submit] {
            background-color: #4CAF50;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }

        .feedback-form input[type=submit]:hover {
            background-color: #45a049;
        }

        .thank-you-message {
            display: none;
            text-align: center;
            margin-top: 20px;
        }

        .btn-home {
            background-color: #333;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }

        .btn-home:hover {
            background-color: #555;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <a href="home.php">Home</a>
    </div>
    <div class="feedback-container">
        <h1>Feedback</h1>
        <div class="feedback-form">
            <form id="feedbackForm" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>

                <label for="email">Email:</label>
                <input type="text" id="email" name="email" required>

                <label for="feedback">Feedback:</label>
                <textarea id="feedback" name="feedback" required></textarea>

                <input type="submit" value="Submit">
            </form>
            <div class="thank-you-message" id="thankYouMessage">
                <p>Thank you for your feedback!</p>
                <a href="home.php" class="btn-home">Go Home</a>
            </div>
        </div>
    </div>
</body>
</html>
