
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="styles.css"> <!-- Include the CSS file -->
    <style>
        body {
            background: rgb(96,116,210);
            background: linear-gradient(90deg, rgba(96,116,210,1) 0%, rgba(135,192,255,1) 44%, rgba(83,255,215,1) 100%);
        }
        
        h1 {
            font-size: 30px;
            color: #1C3D54;
            font-family: Verdana;
            text-align: center;
            margin-top: 200px;
            font-size: 70px;
            margin-bottom: 0px;
            text-shadow: 5px 5px #CAE6FF;
        }

        h2 {
            font-size: 90px;
            color: #1C3D54;
            font-family: Verdana;
            text-align: center;
            margin: 0px;
            text-shadow: 5px 5px #CAE6FF;
        }

        .buttons {
            font-size: 25px;
            font-family: Verdana;
            text-align: center;
            margin-top: 120px;
        }

        a {
            background-color: white;
            padding: 20px;
            border-radius: 20px;
        }

        a:hover {
            background-color: #ddd;
            color: green;
        }
    
    </style>
</head>
<body class="home-page"> <!-- Add the home-page class for styling -->
    <div class="home-container"> <!-- Use the home-container class for styling -->
        <h1>Welcome to </h1>
        <h2>Smart Minibus System </h2>
        <div class="buttons">
            <a href="balance.php" class="button">Account Balance</a>
            <a href="book.php" class="button">Book Minibus</a>
            <a href="feedback.php" class="button">Provide Feedback</a>
             <!-- Add tracking button -->
            <!-- Add more buttons for other functionalities -->
        </div>
    </div>
</body>
</html>
