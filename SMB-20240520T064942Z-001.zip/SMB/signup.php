<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="styles.css"> <!-- Include the CSS file -->
</head>
<body class="login-page"> <!-- Add the login-page class for styling -->
    <div class="login-container"> <!-- Use the login-container class for styling -->
        <h2>Sign Up</h2>
        <form action="signup_process.php" method="post">
            <input type="text" name="name" placeholder="Name" required><br><br>
            <input type="email" name="email" placeholder="Email" required><br><br>
            <input type="password" name="password" placeholder="Password" required><br><br>
            <input type="submit" value="Sign Up">
        </form>
        <p>Already have an account? <a href="Index.php">Login</a></p> <!-- Link to the login page -->
    </div>
</body>
</html>
