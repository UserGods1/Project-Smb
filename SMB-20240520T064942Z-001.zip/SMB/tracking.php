<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minibus Tracking</title>
    <link rel="stylesheet" href="styles.css"> <!-- Include the CSS file -->
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        .navbar {
            overflow: hidden;
            background-color: #333;
        }

        .navbar a {
            float: left;
            display: block;
            color: white;
            text-align: center;
            padding: 14px 20px;
            text-decoration: none;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        .tracking-container {
            margin-top: 20px;
        }
    </style>
</head>
<body class="tracking-page"> <!-- Add the tracking-page class for styling -->
    <div class="navbar">
        <a href="home.php">Home</a>
    </div>

    <div class="form-container hidden" id="booking-details">
            <?php
            // Include the QR Code library
            include "phpqrcode/qrlib.php";

            // Function to generate QR code and return the file name
            function generateQRCode($data) {
                // QR code file name
                $qrFilename = "booking_qr.png";
                
                // Generate QR code
                QRcode::png($data, $qrFilename);

                // Return QR code file name
                return $qrFilename;
            }

            // Display booking details if form is submitted
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Check if booking details are submitted
                if (isset($_POST['passenger'], $_POST['start_point'], $_POST['end_point'], $_POST['date'], $_POST['minibus'])) {
                    // Retrieve the booking details
                    $passenger = $_POST['passenger'];
                    $startPoint = $_POST['start_point'];
                    $endPoint = $_POST['end_point'];
                    $date = $_POST['date'];
                    $minibus = $_POST['minibus'];

                    // Database connection and other retrieval logic...

                    // Retrieve passenger details and minibus details
                    // Replace this with your database retrieval logic
                    $passengerName = 'passenger';
                    $minibusLicensePlate = "ABC123";

                    // Generate QR code data (you can customize this as needed)
                    $qrData = "Passenger: $passengerName\nStart Point: $startPoint\nEnd Point: $endPoint\nDate: $date\nMinibus: $minibusLicensePlate";

                    // Generate QR code and get the file name
                    $qrFilename = generateQRCode($qrData);

                    // Display booking details
                    ?>
                    <h3>Booking Details</h3>
                    <table>
                        <tr>
                            <th>Passenger</th>
                            <th>Start Point</th>
                            <th>End Point</th>
                            <th>Date</th>
                            <th>Minibus</th>
                            <th>QR Code</th>
                        </tr>
                        <tr>
                            <td><?php echo $passengerName; ?></td>
                            <td><?php echo $startPoint; ?></td>
                            <td><?php echo $endPoint; ?></td>
                            <td><?php echo $date; ?></td>
                            <td><?php echo $minibusLicensePlate; ?></td>
                            <td><img src="<?php echo $qrFilename; ?>" alt="QR Code"></td>
                        </tr>
                    </table>
                    <script>hideBookingFormAndShowDetails();</script>
                    <?php
                }
            }
            ?>
        </div>

        <div class="tracking-container"> <!-- Use the tracking-container class for styling -->
            <h2>Minibus Tracking</h2>
            <table>
                <tr>
                    <th>Minibus ID</th>
                    <th>License Plate</th>
                    <th>Capacity</th>
                    <th>Route ID</th>
                    <th>Current Location</th>
                </tr>
                <?php
                // Database connection
                $conn = new mysqli("127.0.0.1", "sqluser", "andrearojo", "SBM");

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Retrieve minibus data for tracking
                $sql = "SELECT * FROM Minibus";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["MinibusID"] . "</td>";
                        echo "<td>" . $row["LicensePlate"] . "</td>";
                        echo "<td>" . $row["Capacity"] . "</td>";
                        echo "<td>" . $row["RouteID"] . "</td>";
                        echo "<td>" . $row["CurrentLocation"] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No minibus data available</td></tr>";
                }

                $conn->close();
                ?>
            </table>
        </div>
</body>
</html>
