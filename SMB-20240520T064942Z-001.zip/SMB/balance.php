<?php
// Database connection
$conn = mysqli_connect("127.0.0.1", "root", "andrearojo", "SBM");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch account balance from PassengerInfo table
$sql = "SELECT AccountBalance FROM PassengerInfo WHERE Username = 'admin'"; // Assuming 'admin' is the currently logged-in user
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $accountBalance = $row["AccountBalance"];
} else {
    $accountBalance = 0.00;
}

// Close database connection
mysqli_close($conn);

// Function to add $100 to the account balance
function addToBalance() {
    // Database connection
    $conn = mysqli_connect("127.0.0.1", "sqluser", "andrearojo", "SBM");
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Update account balance
    $sql = "UPDATE PassengerInfo SET AccountBalance = AccountBalance + 100 WHERE Username = 'admin'"; // Assuming 'admin' is the currently logged-in user
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Added $100 to the balance.');</script>";
    } else {
        echo "Error updating record: " . mysqli_error($conn);
    }

    // Close database connection
    mysqli_close($conn);
}

// Check if the add balance button is clicked
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_balance'])) {
    addToBalance();
    // Refresh the page after adding balance
    echo "<meta http-equiv='refresh' content='0'>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Balance</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .balance-container {
            text-align: center;
        }
        .balance {
            font-size: 24px;
            margin-bottom: 20px;
        }
        .btn {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="balance-container">
        <h1>Account Balance</h1>
        <div class="balance">
            Current Balance: $<?php echo $accountBalance; ?>
        </div>
        <form method="post">
            <button class="btn" type="submit" name="add_balance">Add $100 to Balance</button>
        </form>
        <br>
        <a href="home.php" class="btn">Home</a>
    </div>
</body>
</html>
