<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minibus Booking and Tracking</title>
    <link rel="stylesheet" href="styles.css"> <!-- Include the CSS file -->
    <style>
        h1 {
            font-size: 80px;
            color: #1C3D54;
            font-family: Verdana;
            text-align: center;
            margin-bottom: 20px;
            margin-top: 0px;    
        }

        h2 {
            font-size: 50px;
            color: #1C3D54;
            font-family: Verdana;
            text-align: center;
            margin-top: 150px;
            margin-bottom: 10px;
        }

        h3 {
            font-size: 60x;
            color: #1C3D54;
            font-family: Verdana;
            text-align: center;
            margin-bottom: 20px;
            margin-top: 0px;    
        }

        body {
            background: rgb(96,116,210);
            background: linear-gradient(90deg, rgba(96,116,210,1) 0%, rgba(135,192,255,1) 44%, rgba(83,255,215,1) 100%);
            margin: 0px;
            width: 100%;
        }
        table {
            font-family: Verdana;
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            background-color: #f2f2f2;
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #4B5B65;
            color: #F4F4F4;
        }
        .navbar {
        overflow: hidden;
        background-color: #4B5B65;
        margin-bottom: 150px;
        }   

        .navbar a{
         float: left;
         color: #f2f2f2;
         text-align: center;
         padding: 20px 20px;
         text-decoration: none;
         font-size: 20px;
        }

        .navbar a:hover {
            background-color: #ddd;
            color: black;
        }

        input[type=text], select, textarea {
        width: 100%;
        padding: 12px;
        border: 1px solid #ccc;
        border-radius: 4px;
        resize: vertical;
        }


        input[type=submit] {
        background-color: #04AA6D;
        color: white;
        padding: 12px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

.hidden {
            display: none;
        }



    </style>
    <script>
        function updateFields() {
            var endPoint = document.getElementById("end_point").value;
            // Set the current date as the value for date
            var currentDate = new Date().toISOString().slice(0,10);
            document.getElementById("date").value = currentDate;
        }

        function hideBookingFormAndShowDetails() {
            document.getElementById("booking-form").classList.add("hidden");
            document.getElementById("booking-details").classList.remove("hidden");
        }
    </script>
</head>
<body class="tracking-page"> <!-- Add the tracking-page class for styling -->
    <div class="navbar">
        <a href="home.php">Home</a>
    </div>


    <div>
        
        <div class="form-container" id="booking-form">
            <h1>Book a Minibus</h1>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <label for="passenger">Passenger:</label>
                <select name="passenger" id="passenger">
                    <?php
                    // Database connection and fetching passengers
                    $conn = mysqli_connect("127.0.0.1", "sqluser", "andrearojo", "SBM");
                    if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                    }
                    $sql = "SELECT PassengerID, Username FROM PassengerInfo";
                    $result = mysqli_query($conn, $sql);
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<option value='" . $row['PassengerID'] . "'>" . $row['Username'] . "</option>";
                        }
                    } else {
                        echo "<option value=''>No passengers found</option>";
                    }
                    mysqli_close($conn);
                    ?>
                </select>
                <br><br>

                <label for="start_point">Start Point:</label>
                <select name="start_point" id="start_point">
                    <?php
                    // Query to fetch start points
                    $conn = mysqli_connect("127.0.0.1", "sqluser", "andrearojo", "SBM");
                    if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                    }
                    $sql = "SELECT DISTINCT StartPoint FROM Route";
                    $result = mysqli_query($conn, $sql);
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<option value='" . $row['StartPoint'] . "'>" . $row['StartPoint'] . "</option>";
                        }
                    } else {
                        echo "<option value=''>No start points found</option>";
                    }
                    mysqli_close($conn);
                    ?>
                </select>
                <br><br>

                <label for="end_point">End Point:</label>
                <select name="end_point" id="end_point" onchange="updateFields()">
                    <?php
                    // Query to fetch end points
                    $conn = mysqli_connect("127.0.0.1", "sqluser", "andrearojo", "SBM");
                    if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                    }
                    $sql = "SELECT DISTINCT EndPoint FROM Route";
                    $result = mysqli_query($conn, $sql);
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<option value='" . $row['EndPoint'] . "'>" . $row['EndPoint'] . "</option>";
                        }
                    } else {
                        echo "<option value=''>No end points found</option>";
                    }
                    mysqli_close($conn);
                    ?>
                </select>
                <br><br>

                <label for="date">Date:</label>
                <input type="date" name="date" id="date" required>
                <br><br>

                <label for="minibus">Minibus:</label>
                <select name="minibus" id="minibus">
                    <?php
                    // Populate minibuses based on end point (dynamically if needed)
                    $conn = mysqli_connect("127.0.0.1", "sqluser", "andrearojo", "SBM");
                    if (!$conn) {
                        die("Connection failed: " . mysqli_connect_error());
                    }
                    $sql = "SELECT MinibusID, LicensePlate FROM Minibus";
                    $result = mysqli_query($conn, $sql);
                    if (mysqli_num_rows($result) > 0
                    ) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<option value='" . $row['MinibusID'] . "'>" . $row['LicensePlate'] . "</option>";
                        }
                    } else {
                        echo "<option value=''>No minibuses found</option>";
                    }
                    mysqli_close($conn);
                    ?>
                </select>
                <br><br>

                <input type="submit" value="Book Now">
            </form>
        </div>

<div class="form-container hidden" id="booking-details">
    <?php
    // Include the QR Code library
    include "phpqrcode/qrlib.php";

    // Function to generate QR code and return the file name
    function generateQRCode($data) {
        // QR code file name
        $qrFilename = "booking_qr.png";
        
        // Generate QR code
        QRcode::png($data, $qrFilename);

        // Return QR code file name
        return $qrFilename;
    }

    // Display booking details if form is submitted
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Check if booking details are submitted
        if (isset($_POST['passenger'], $_POST['start_point'], $_POST['end_point'], $_POST['date'], $_POST['minibus'])) {
            // Retrieve the booking details
            $passenger = $_POST['passenger'];
            $startPoint = $_POST['start_point'];
            $endPoint = $_POST['end_point'];
            $date = $_POST['date'];
            $minibus = $_POST['minibus'];

            // Database connection and other retrieval logic...

            // Retrieve passenger details and minibus details
            // Replace this with your database retrieval logic
            $passengerName = "John Doe";
            $minibusLicensePlate = "ABC123";

            // Generate QR code data (you can customize this as needed)
            $qrData = "Passenger: $passengerName\nStart Point: $startPoint\nEnd Point: $endPoint\nDate: $date\nMinibus: $minibusLicensePlate";

            // Generate QR code and get the file name
            $qrFilename = generateQRCode($qrData);

            // Display booking details
            echo "<h3>Booking Details</h3>";
            echo "<table>";
            echo "<tr><th>Passenger</th><th>Start Point</th><th>End Point</th><th>Date</th><th>Minibus</th><th>Cost</th><th>Balance</th><th>QR Code</th></tr>";
            // Display cost and balance
            $cost = rand(10, 50);
            $balance = 200; // Replace this with the actual balance from the database
            echo "<tr><td>$passengerName</td><td>$startPoint</td><td>$endPoint</td><td>$date</td><td>$minibusLicensePlate</td><td>$cost</td><td>$balance</td><td><img src='$qrFilename' alt='QR Code'></td></tr>";
            echo "</table>";

            // JavaScript to hide the booking form and show the booking details
            echo "<script>hideBookingFormAndShowDetails();</script>";
        }
    }
    ?>
</div>

<div class="tracking-container"> <!-- Use the tracking-container class for styling -->
    <h2>Minibus Tracking</h2>
    <table>
        <tr>
            <th>Minibus ID</th>
            <th>License Plate</th>
            <th>Capacity</th>
            <th>Route ID</th>
            <th>Current Location</th>
        </tr>
        <?php
        // Database connection
        $conn = new mysqli("127.0.0.1", "sqluser", "andrearojo", "SBM");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Retrieve minibus data for tracking
        $sql = "SELECT * FROM Minibus";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["MinibusID"] . "</td>";
                echo "<td>" . $row["LicensePlate"] . "</td>";
                echo "<td>" . $row["Capacity"] . "</td>";
                echo "<td>" . $row["RouteID"] . "</td>";
                echo "<td>" . $row["CurrentLocation"] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>No minibus data available</td></tr>";
        }

        $conn->close();
        ?>
    </table>
</div>

    </body>
    </html>