<?php
// Database connection
$servername = "127.0.0.1";
$username = "sqluser";
$password = "andrearojo";
$dbname = "sbm";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$email = $_POST['email'];
$password = $_POST['password'];

// Check if user exists and verify password
$sql = "SELECT * FROM PassengerInfo WHERE Email='$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['PasswordHash'])) {
        // Password is correct, generate session ID
        $sessionID = uniqid();

        // Store session ID in database
        $insertSessionSQL = "INSERT INTO Session (SessionID, SessionData) VALUES ('$sessionID', '{$row['PassengerID']}')";
        if ($conn->query($insertSessionSQL) === TRUE) {
            // Set session cookie
            setcookie('sessionID', $sessionID, time() + (86400 * 30), "/"); // 30 days expiration
            // Redirect to home page
            header("Location: home.php");
            exit();
        } else {
            echo "Error creating session: " . $conn->error;
        }
    } else {
        echo "Invalid email or password";
    }
} else {
    echo "Invalid email or password";
}

$conn->close();
?>
