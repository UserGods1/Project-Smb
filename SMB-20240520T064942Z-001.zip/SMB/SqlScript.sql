-- Create the database
CREATE SCHEMA IF NOT EXISTS sbm;
USE sbm;

-- Create the Route table
CREATE TABLE Route (
    RouteID INT AUTO_INCREMENT PRIMARY KEY,
    StartPoint VARCHAR(100),
    EndPoint VARCHAR(100),
    TotalDistance DECIMAL(10, 2)
);

-- Insert sample data into Route table
INSERT INTO Route (StartPoint, EndPoint, TotalDistance)
VALUES ('IIT', 'Gaisano Mall', 10.00),
       ('Gaisano Mall', 'Robinsons Mall', 15.00),
       ('Robinsons Mall', 'IIT', 12.00),
       ('South Bound Terminal', 'West Bound Terminal', 5.00),
       ('Iligan Central School', 'Pala-o Market', 8.00),
       ('Wet Market', 'Plaza', 3.00);

-- Create the Minibus table
CREATE TABLE Minibus (
    MinibusID INT AUTO_INCREMENT PRIMARY KEY,
    LicensePlate VARCHAR(20) UNIQUE,
    Capacity INT,
    RouteID INT,
    CurrentLocation VARCHAR(255),
    FOREIGN KEY (RouteID) REFERENCES Route(RouteID)
);

-- Insert sample data into Minibus table
INSERT INTO Minibus (LicensePlate, Capacity, RouteID, CurrentLocation)
VALUES ('ABC123', 20, 1, 'IIT'),
       ('XYZ789', 25, 2, 'Gaisano Mall'),
       ('DEF456', 30, 3, 'Robinsons Mall'),
       ('GHI789', 25, 4, 'South Bound Terminal'),
       ('JKL012', 20, 5, 'Iligan Central School');

-- Create the Driver table
CREATE TABLE Driver (
    DriverID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100),
    Phone VARCHAR(15),
    Email VARCHAR(100) UNIQUE,
    LicenseNumber VARCHAR(50),
    MinibusID INT,
    FOREIGN KEY (MinibusID) REFERENCES Minibus(MinibusID)
);

-- Insert sample data into Driver table
INSERT INTO Driver (Name, Phone, Email, LicenseNumber, MinibusID)
VALUES ('John Doe', '123-456-7890', 'john@example.com', 'DL123456', 1),
       ('Jane Smith', '987-654-3210', 'jane@example.com', 'DL654321', 2),
       ('Alice Johnson', '555-555-5555', 'alice@example.com', 'DL789012', 3),
       ('Bob Williams', '111-222-3333', 'bob@example.com', 'DL345678', 4),
       ('Emma Davis', '444-444-4444', 'emma@example.com', 'DL901234', 5);

-- Create the Stop table
CREATE TABLE Stop (
    StopID INT AUTO_INCREMENT PRIMARY KEY,
    RouteID INT,
    StopName VARCHAR(100),
    Location VARCHAR(255),
    FOREIGN KEY (RouteID) REFERENCES Route(RouteID)
);

-- Insert sample data into Stop table
INSERT INTO Stop (RouteID, StopName, Location)
VALUES (1, 'Stop A', 'IIT'),
       (1, 'Stop B', 'Gaisano Mall'),
       (2, 'Stop C', 'Gaisano Mall'),
       (2, 'Stop D', 'Robinsons Mall'),
       (3, 'Stop E', 'Robinsons Mall'),
       (3, 'Stop F', 'IIT'),
       (4, 'Stop G', 'South Bound Terminal'),
       (4, 'Stop H', 'West Bound Terminal'),
       (5, 'Stop I', 'Iligan Central School'),
       (5, 'Stop J', 'Pala-o Market'),
       (6, 'Stop K', 'Wet Market'),
       (6, 'Stop L', 'Plaza');

-- Create the PassengerInfo table
CREATE TABLE PassengerInfo (
    PassengerID INT AUTO_INCREMENT PRIMARY KEY,
    Username VARCHAR(100),
    Email VARCHAR(100) UNIQUE,
    PasswordHash VARCHAR(255),
    AccountBalance DECIMAL(10, 2) DEFAULT 0.00
);

-- Insert sample data into PassengerInfo table
INSERT INTO PassengerInfo (Username, Email, PasswordHash, AccountBalance)
VALUES ('admin', 'admin@gmail.com', 'admin123', 1000.00),
       ('user1', 'user1@example.com', 'password1', 500.00),
       ('user2', 'user2@example.com', 'password2', 750.00);

-- Create the Feedback table
CREATE TABLE Feedback (
    FeedbackID INT AUTO_INCREMENT PRIMARY KEY,
    PassengerID INT,
    MinibusID INT,
    Date DATE,
    Rating INT,
    Comments TEXT,
    FOREIGN KEY (PassengerID) REFERENCES PassengerInfo(PassengerID),
    FOREIGN KEY (MinibusID) REFERENCES Minibus(MinibusID)
);

-- Insert sample data into Feedback table
INSERT INTO Feedback (PassengerID, MinibusID, Date, Rating, Comments)
VALUES (2, 1, '2024-05-20', 4, 'Good service.'),
       (3, 2, '2024-05-21', 5, 'Excellent experience.');

-- Create the Booking table
CREATE TABLE Booking (
    BookingID INT AUTO_INCREMENT PRIMARY KEY,
    PassengerID INT,
    MinibusID INT,
    RouteID INT,
    BookingDate DATE,
    QRCode VARCHAR(255),
    PaymentStatus ENUM('Pending', 'Paid', 'Cancelled'),
    PointsEarned INT,
    StartLocation VARCHAR(255),
    EndLocation VARCHAR(255),
    FOREIGN KEY (PassengerID) REFERENCES PassengerInfo(PassengerID),
    FOREIGN KEY (MinibusID) REFERENCES Minibus(MinibusID),
    FOREIGN KEY (RouteID) REFERENCES Route(RouteID)
);

-- Insert sample data into Booking table
INSERT INTO Booking (PassengerID, MinibusID, RouteID, BookingDate, QRCode, PaymentStatus, PointsEarned, StartLocation, EndLocation)
VALUES (2, 1, 1, '2024-05-20', 'ABC123XYZ', 'Paid', 10, 'StartLocation', 'EndLocation');

-- Create the Session table
CREATE TABLE Session (
    SessionID VARCHAR(255) PRIMARY KEY,
    SessionData TEXT,
    LastAccessTime TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
