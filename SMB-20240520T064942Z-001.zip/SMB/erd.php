<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ERD Overview</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="erd-container">
        <div class="entity">
            <h3>Passenger</h3>
            <p>PassengerID</p>
            <p>Name</p>
            <p>Email</p>
            <p>Phone</p>
            <p>AccountBalance</p>
            <p>TotalPoints</p>
            <p>RegisteredDate</p>
        </div>
        <div class="entity">
            <h3>Minibus</h3>
            <p>MinibusID</p>
            <p>LicensePlate</p>
            <p>Capacity</p>
            <p>RouteID</p>
            <p>CurrentLocation</p>
        </div>
        <div class="entity">
            <h3>Route</h3>
            <p>RouteID</p>
            <p>StartPoint</p>
            <p>EndPoint</p>
            <p>TotalDistance</p>
        </div>
        <div class="entity">
            <h3>Booking</h3>
            <p>BookingID</p>
            <p>PassengerID</p>
            <p>MinibusID</p>
            <p>RouteID</p>
            <p>BookingDate</p>
            <p>QRCode</p>
            <p>PaymentStatus</p>
            <p>PointsEarned</p>
            <p>StartLocation</p>
            <p>EndLocation</p>
        </div>
        <div class="entity">
            <h3>Driver</h3>
            <p>DriverID</p>
            <p>Name</p>
            <p>Phone</p>
            <p>Email</p>
            <p>LicenseNumber</p>
            <p>MinibusID</p>
        </div>
        <div class="entity">
            <h3>Payment</h3>
            <p>PaymentID</p>
            <p>BookingID</p>
            <p>PaymentDate</p>
            <p>Amount</p>
            <p>PaymentMethod</p>
            <p>TransactionID</p>
        </div>
        <div class="entity">
            <h3>Feedback</h3>
            <p>FeedbackID</p>
            <p>PassengerID</p>
            <p>MinibusID</p>
            <p>Date</p>
            <p>Rating</p>
            <p>Comments</p>
        </div>
        <div class="entity">
            <h3>Stop</h3>
            <p>StopID</p>
            <p>RouteID</p>
            <p>StopName</p>
            <p>Location</p>
        </div>
        <div class="relationship">
            <span>Passenger</span>--<span>Booking</span>--<span>Minibus</span>
        </div>
        <div class="relationship">
            <span>Route</span>--<span>Minibus</span>
        </div>
        <div class="relationship">
            <span>Route</span>--<span>Booking</span>
        </div>
        <div class="relationship">
            <span>Driver</span>--<span>Minibus</span>
        </div>
        <div class="relationship">
            <span>Booking</span>--<span>Payment</span>
        </div>
        <div class="relationship">
            <span>Passenger</span>--<span>Feedback</span>--<span>Minibus</span>
        </div>
        <div class="relationship">
            <span>Route</span>--<span>Stop</span>
        </div>
    </div>
</body>
</html>
