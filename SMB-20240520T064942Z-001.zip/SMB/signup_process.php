<?php
// Database connection
$servername = "127.0.0.1";
$username = "sqluser";
$password = "andrearojo";
$dbname = "SBM";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password

// Insert user data into PassengerInfo table
$sql = "INSERT INTO PassengerInfo (Username, Email, PasswordHash)
        VALUES ('$name', '$email', '$password')";

if ($conn->query($sql) === TRUE) {
    // Redirect to login page after successful signup
    header("Location: Index.php");
    exit();
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
