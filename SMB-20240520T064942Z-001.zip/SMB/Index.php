<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="styles.css"> <!-- Include the CSS file -->
    <style> 

        body {
            margin: none;
            width: 100%;
            margin: 0px;
            background: rgb(96,116,210);
            background: linear-gradient(90deg, rgba(96,116,210,1) 0%, rgba(135,192,255,1) 44%, rgba(83,255,215,1) 100%);
        }

        h2 {
            font-size: 50px;
            color: #1C3D54;
            font-family: Verdana;
            text-align: center;
            margin-top: 50px;
        }
    
    </style>
</head>
<body class="login-page"> <!-- Add the login-page class for styling -->
    <div class="login-container"> <!-- Use the login-container class for styling -->
        <h2>Login</h2>
        <form action="login_process.php" method="post">
            <input type="email" name="email" placeholder="Email" required><br><br>
            <input type="password" name="password" placeholder="Password" required><br><br>
            <input type="submit" value="Login">
        </form>
        <p>Don't have an account yet? <a href="signup.php">Sign Up</a></p> <!-- Link to the sign-up page -->
    </div>
</body>
</html>
